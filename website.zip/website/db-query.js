
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./books.db');

const query = process.argv[2] || 'SELECT * FROM users';

db.all(query, [], (err, rows) => {
    if (err) {
        console.error(err.message);
    } else {
        console.table(rows);
    }
    db.close();
});