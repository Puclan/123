
const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('./books.db', (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the books database.');
});


db.serialize(() => {
  
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS book_status (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  book_title TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('read', 'planned', 'favorite')),
  FOREIGN KEY(user_id) REFERENCES users(id),
  UNIQUE(user_id, book_title) 
)`);
  
  
  db.run('CREATE INDEX IF NOT EXISTS idx_book_status ON book_status(user_id, book_title)');
});

module.exports = db;