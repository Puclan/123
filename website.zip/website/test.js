// test.js
console.log("Node.js работает корректно!");