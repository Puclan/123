
const API_URL = '/api';
const enableDebug = true;

function debugLog(...args) {
  if (enableDebug) {
    console.log('[DEBUG]', ...args);
  }
}



document.getElementById('register-btn').addEventListener('click', async () => {
  const username = document.getElementById('register-username').value;
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;
  
  try {
    const response = await fetch(`${API_URL}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password })
    });
    
    const data = await response.json();
    if (response.ok) {
      alert('Registration successful! Please login.');
      document.getElementById('register-form').style.display = 'none';
      document.getElementById('login-form').style.display = 'block';
    } else {
      alert(`Error: ${data.error}`);
    }
  } catch (error) {
    alert('Network error');
  }
});


document.getElementById('login-btn').addEventListener('click', async () => {
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;
  
  try {
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    
    const data = await response.json();
    if (response.ok) {
      localStorage.setItem('username', username)
      localStorage.setItem('token', data.token);
      alert('Login successful!');
      updateUI();
    } else {
      alert(`Error: ${data.error}`);
    }
  } catch (error) {
    alert('Network error');
  }
});


function setupBookStatusListeners() {
  document.querySelectorAll('.book-status select').forEach(select => {
    const bookElement = select.closest('.book');
    if (!bookElement) return;
    
    const bookTitle = bookElement.dataset.bookTitle;
    if (!bookTitle) {
      debugLog("Book title not found in data attribute");
      return;
    }
    
    debugLog("Detected book:", bookTitle);
    
    // Загрузка текущего статуса
    loadBookStatus(bookTitle, select);
    
    // Сохранение при изменении
    select.addEventListener('change', () => {
      debugLog("Status changed:", bookTitle, "->", select.value);
      saveBookStatus(bookTitle, select.value);
    });
  });
}

async function loadBookStatus(bookTitle, selectElement) {
  debugLog("Loading status for:", bookTitle);
  const token = localStorage.getItem('token');
  if (!token) return;
  
  try {
    console.log("Loading status for:", bookTitle);
    
    const response = await fetch(
  `${API_URL}/get-status?bookTitle=${encodeURIComponent(bookTitle)}`, // book_title → bookTitle
  { headers: { 'Authorization': `Bearer ${token}` } }
);
    
    const data = await response.json();
    console.log("Status response:", data);
    
    if (response.ok && data.status) {
      selectElement.value = data.status;
      console.log("Status set to:", data.status);
    }
  } catch (error) {
    console.error('Error loading status:', error);
  }
}

async function saveBookStatus(bookTitle, status) {
  debugLog("Saving status:", {bookTitle, status});
  const token = localStorage.getItem('token');
  if (!token) {
    alert('Please login to save your book status');
    return;
  }
  
  try {
    console.log("Saving status:", {bookTitle, status});
    
    const response = await fetch(`${API_URL}/save-status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ bookTitle, status })
    });
    
    const responseData = await response.json();
    console.log("Save status response:", responseData);
    
    if (response.ok) {
      console.log('Status saved successfully');
    } else {
      console.error('Error saving status:', responseData.error);
    }
  } catch (error) {
    console.error('Network error:', error);
  }
  if (!response.ok) {
  const errorData = await response.json();
  throw new Error(errorData.error || 'Failed to save status');
}
}




function updateUI() {
  const token = localStorage.getItem('token');
  if (token) {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('user-greeting').style.display = 'block';
    
    const username = localStorage.getItem('username');
    document.getElementById('username-display').textContent = username;
    
    setupBookStatusListeners();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  updateUI();

document.getElementById('logout-btn').addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    alert('Вы вышли из аккаунта');
    location.reload();
});
  

  document.getElementById('show-register').addEventListener('click', () => {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
  });
  
  document.getElementById('show-login').addEventListener('click', () => {
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
  });
});

document.getElementById('logout-btn').addEventListener('click', () => {
  localStorage.removeItem('token');
  alert('You have been logged out');
  location.reload();
});