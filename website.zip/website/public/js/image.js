
document.querySelectorAll('.box').forEach(box => {
    box.addEventListener('mouseenter', () => {
      const img = box.querySelector('img');
      img.style.zIndex = '10'; 
    });
  
    box.addEventListener('mouseleave', () => {
      const img = box.querySelector('img');
      img.style.zIndex = '1';
    });
  });
