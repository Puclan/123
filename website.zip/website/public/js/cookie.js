
function setCookie(name, value, days) {
  const date = new Date();
  date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
  document.cookie = `${name}=${value};expires=${date.toUTCString()};path=/`;
}

function getCookie(name) {
  return document.cookie.split('; ')
    .find(row => row.startsWith(`${name}=`))
    ?.split('=')[1];
}

function clearCookie(name) {
  document.cookie = `${name}=;expires=Thu, 01 Jan 2030 00:00:00 GMT;path=/`;
}


function saveVisitData() {
  const currentPage = window.location.pathname.split('/').pop();
  const visitTime = new Date().toISOString();

  localStorage.setItem('last_visited_page', currentPage);
  localStorage.setItem('last_visit_time', visitTime);
  
  setCookie('last_visited', currentPage, 30);
  setCookie('last_visit_time', visitTime, 30);
}

function showVisitData() {
  const lastPage = localStorage.getItem('last_visited_page') || getCookie('last_visited');
  const visitTime = localStorage.getItem('last_visit_time') || getCookie('last_visit_time');
  
  if (lastPage && lastPage !== 'main.html') {
    document.getElementById('last-page').textContent = 
      lastPage.replace('.html', '').replace('-', ' ');
  } else {
    document.getElementById('last-page').textContent = 'Главная';
  }
  
  if (visitTime) {
    document.getElementById('visit-time').textContent = 
      new Date(visitTime).toLocaleString();
  }
  if (!lastPage && !visitTime) {
    document.querySelector('.contact-info').style.display = 'none';
  }
}

function clearHistory() {

  localStorage.removeItem('last_visited_page');
  localStorage.removeItem('last_visit_time');
  
  clearCookie('last_visited');
  clearCookie('last_visit_time');

  document.getElementById('last-page').textContent = 'нет данных';
  document.getElementById('visit-time').textContent = 'нет данных';
  
  alert('История просмотра очищена!');
}

document.addEventListener('DOMContentLoaded', function() {
 
  saveVisitData();
  showVisitData();
  
  document.getElementById('clear-history-btn').addEventListener('click', clearHistory);
});

document.addEventListener('DOMContentLoaded', function() {
  if (!getCookie('cookies_accepted')) {
    document.getElementById('cookie-notice').style.display = 'flex';
  }


  document.getElementById('accept-cookies').addEventListener('click', function() {
    setCookie('cookies_accepted', 'true', 365);
    document.getElementById('cookie-notice').style.display = 'none';
  });

});