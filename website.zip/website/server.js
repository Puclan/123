const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const util = require('util');
const logFile = fs.createWriteStream('server.log', { flags: 'a' });
const logStdout = process.stdout;

console.log = function() {
  logFile.write(util.format.apply(null, arguments) + '\n');
  logStdout.write(util.format.apply(null, arguments) + '\n');
};
console.error = console.log;


const app = express();
const PORT = 3000;
const SECRET_KEY = 'your_secret_key_123!';

app.use(bodyParser.json());
app.use(express.static('public'));

app.post('/api/register', async (req, res) => {
  try {
    const { username, password, email } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    db.run(
      `INSERT INTO users (username, password, email) VALUES (?, ?, ?)`,
      [username, hashedPassword, email],
      function(err) {
        if (err) return res.status(400).json({ error: err.message });
        res.status(201).json({ id: this.lastID });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  
  db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
    if (err || !user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ userId: user.id }, SECRET_KEY, { expiresIn: '1h' });
    res.json({ token });
  });
});

app.post('/api/save-status', (req, res) => {
  console.log("Received save-status request:", req.body);
   console.log(`[${new Date().toISOString()}] Save status request:`, req.body);
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

 try {
  const { userId } = jwt.verify(token, SECRET_KEY);
  const { bookTitle, status } = req.body;
  
  db.run(
    `INSERT INTO book_status (user_id, book_title, status) 
     VALUES (?, ?, ?)
     ON CONFLICT(user_id, book_title) 
     DO UPDATE SET status = excluded.status`, // Исправленный SQL-запрос
    [userId, bookTitle, status],
    function(err) {
      if (err) {
        console.error('DB error in save-status:', err);
        return res.status(500).json({ error: 'Database error' });
      }
      res.json({ success: true });
    }
  );
} catch (error) {
  console.error('Token error in save-status:', error);
  res.status(401).json({ error: 'Invalid token' });
}
});


app.get('/api/get-status', (req, res) => {
  console.log("Received get-status request:", req.query);
  console.log(`[${new Date().toISOString()}] Get status request:`, req.query);
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  try {
  const { userId } = jwt.verify(token, SECRET_KEY);
  const bookTitle = req.query.bookTitle; // Изменено с book_title на bookTitle
  
  db.get(
    `SELECT status FROM book_status WHERE user_id = ? AND book_title = ?`,
    [userId, bookTitle],
    (err, row) => {
      if (err) {
        console.error('DB error in get-status:', err);
        return res.status(500).json({ error: 'Database error' });
      }
      res.json({ status: row?.status || '' });
    }
  );
} catch (error) {
  console.error('Token error in get-status:', error);
  res.status(401).json({ error: 'Invalid token' });
}

});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});